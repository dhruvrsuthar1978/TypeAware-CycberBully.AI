const w={HARASSMENT:{severity:"high",color:"#dc2626",patterns:[/\b(loser|stupid|idiot|dumb|fool|hate you|kill yourself|kys)\b/i,/stfu|shut.*up|go away|nobody likes/i,/you're.*trash|you suck/i]},HATE_SPEECH:{severity:"high",color:"#b91c1c",patterns:[/\b(damn|hell|crap)\b/i]},PROFANITY:{severity:"medium",color:"#ea580c",patterns:[/\b(hell|damn|crap|sucks?|pissed)\b/i]},SPAM:{severity:"low",color:"#ca8a04",patterns:[/buy now|click here|limited time|act now/i,/follow my link|check my profile/i]}},d={EXTENSION_ID:chrome.runtime.id,DETECTION_THRESHOLDS:{MIN_TEXT_LENGTH:3,MAX_TEXT_LENGTH:5e3,BATCH_SIZE:5,DEBOUNCE_DELAY:300},UI:{POPUP_FADE_DELAY:5e3,ANIMATION_DURATION:200}};class y{constructor(){this.cache=new Map,this.processingQueue=new Set}async detectContent(e,t){if(!e||e.length<d.DETECTION_THRESHOLDS.MIN_TEXT_LENGTH)return null;const o=this.analyzeWithPatterns(e);return o&&o.category!=="none"&&this.logDetection(o,e,t),o}analyzeWithPatterns(e){for(const[t,o]of Object.entries(w))for(const s of o.patterns)if(s.test(e))return{category:t.toLowerCase(),severity:o.severity,confidence:.85,explanation:`Detected ${t.replace(/_/g," ").toLowerCase()} in content`,suggestion:"Consider using more respectful language",color:o.color};return{category:"none",severity:"low",confidence:0,explanation:"",suggestion:"",color:""}}async logDetection(e,t,o){try{const s={types:[e.category],content:t.substring(0,100),platform:this.detectPlatform(),timestamp:Date.now()};await this.storeDetection(s),await chrome.runtime.sendMessage({action:"updateStats",data:{totalScanned:1,threatsDetected:1}}),console.log("Threat detected:",s)}catch(s){console.error("Detection logging error:",s)}}async storeDetection(e){try{let o=(await chrome.storage.local.get(["detections"])).detections||[];return o.unshift(e),o.length>50&&(o=o.slice(0,50)),await chrome.storage.local.set({detections:o}),!0}catch(t){return console.error("Error storing detection:",t),!1}}detectPlatform(){const e=window.location.hostname.toLowerCase();return e.includes("instagram.com")?"instagram":e.includes("twitter.com")||e.includes("x.com")?"twitter":e.includes("youtube.com")?"youtube":e.includes("reddit.com")?"reddit":e.includes("facebook.com")?"facebook":"web"}}class m{constructor(){this.activePopups=new Set,this.highlightedElements=new WeakMap,this.shadowHost=null,this.shadowRoot=null,this.initShadowDOM()}initShadowDOM(){this.shadowHost=document.createElement("div"),this.shadowHost.id="typeaware-shadow-host",document.body.appendChild(this.shadowHost),this.shadowRoot=this.shadowHost.attachShadow({mode:"open"});const e=new CSSStyleSheet;e.replaceSync(`
      :host {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 14px;
      }

      .typeaware-popup {
        position: fixed;
        background: white;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        border: 2px solid #dc2626;
        z-index: 999999;
        max-width: 350px;
        opacity: 0;
        transform: translateY(-10px) scale(0.95);
        transition: all 0.2s ease;
        pointer-events: none;
      }

      .typeaware-popup.visible {
        opacity: 1;
        transform: translateY(0) scale(1);
        pointer-events: auto;
      }

      .typeaware-popup-header {
        padding: 12px 16px;
        border-bottom: 2px solid #dc2626;
        background: linear-gradient(135deg, #fef2f2, #fee2e2);
        border-radius: 10px 10px 0 0;
        font-weight: 600;
        color: #dc2626;
      }

      .typeaware-popup-content {
        padding: 12px 16px;
        font-size: 13px;
        color: #374151;
      }

      .typeaware-popup-suggestion {
        background: #f0fdf4;
        border: 1px solid #86efac;
        border-radius: 6px;
        padding: 8px 12px;
        margin-top: 8px;
        font-style: italic;
        color: #166534;
        cursor: pointer;
        transition: all 0.15s ease;
      }

      .typeaware-popup-suggestion:hover {
        background: #dcfce7;
        border-color: #4ade80;
      }

      .typeaware-popup-actions {
        padding: 8px 16px 12px;
        border-top: 1px solid #e5e7eb;
        display: flex;
        gap: 8px;
        justify-content: flex-end;
      }

      .typeaware-btn {
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        border: none;
        transition: all 0.15s ease;
      }

      .typeaware-btn-primary {
        background: #dc2626;
        color: white;
      }

      .typeaware-btn-primary:hover {
        background: #b91c1c;
      }

      .typeaware-btn-secondary {
        background: #f1f5f9;
        color: #475569;
        border: 1px solid #e2e8f0;
      }

      .typeaware-btn-secondary:hover {
        background: #e2e8f0;
      }

      .typeaware-fade-out {
        opacity: 0;
        transform: translateY(-10px) scale(0.95);
      }
    `),this.shadowRoot.adoptedStyleSheets=[e]}highlightElement(e,t){if(e.classList.contains("typeaware-highlight"))return;e.classList.add("typeaware-highlight"),e.setAttribute("data-typeaware-category",t.category),e.setAttribute("data-typeaware-severity",t.severity);const o=s=>{s.stopPropagation(),this.showSuggestionPopup(e,t)};e.addEventListener("click",o),this.highlightedElements.set(e,o)}removeHighlight(e){if(!e.classList.contains("typeaware-highlight"))return;e.classList.remove("typeaware-highlight"),e.removeAttribute("data-typeaware-category"),e.removeAttribute("data-typeaware-severity");const t=this.highlightedElements.get(e);t&&(e.removeEventListener("click",t),this.highlightedElements.delete(e))}removeAllHighlights(){document.querySelectorAll(".typeaware-highlight").forEach(e=>{this.removeHighlight(e)})}showSuggestionPopup(e,t){this.hideAllPopups();const o=e.getBoundingClientRect(),s=this.createPopup(t),i=this.calculatePopupPosition(o,s);s.style.left=`${i.left}px`,s.style.top=`${i.top}px`,this.shadowRoot.appendChild(s),setTimeout(()=>s.classList.add("visible"),10),setTimeout(()=>this.hidePopup(s),d.UI.POPUP_FADE_DELAY),this.activePopups.add(s)}calculatePopupPosition(e,t){let n=e.left+window.scrollX,r=e.bottom+window.scrollY+5;return n+350>window.innerWidth+window.scrollX-10&&(n=window.innerWidth+window.scrollX-350-10),n<window.scrollX+10&&(n=window.scrollX+10),r+200>window.innerHeight+window.scrollY-10&&(r=e.top+window.scrollY-200-5,r<window.scrollY+10&&(r=e.bottom+window.scrollY+5)),{left:n,top:r}}createPopup(e){const t=document.createElement("div");t.className="typeaware-popup";const o=document.createElement("div");o.className="typeaware-popup-header",o.textContent=`⚠️ ${this.capitalizeFirst(e.category)} Detected`,t.appendChild(o);const s=document.createElement("div");s.className="typeaware-popup-content";const i=document.createElement("p");if(i.style.margin="0 0 8px",i.style.color="#6b7280",i.textContent=e.explanation||"This content may be harmful or inappropriate.",s.appendChild(i),e.suggestion){const h=document.createElement("div");h.className="typeaware-popup-suggestion",h.textContent=`💡 ${e.suggestion}`,s.appendChild(h)}t.appendChild(s);const n=document.createElement("div");n.className="typeaware-popup-actions";const r=document.createElement("button");r.className="typeaware-btn typeaware-btn-secondary",r.textContent="Dismiss",r.onclick=()=>this.hidePopup(t),n.appendChild(r);const p=document.createElement("button");return p.className="typeaware-btn typeaware-btn-primary",p.textContent="Learn More",p.onclick=()=>window.open("https://typeaware.com","_blank"),n.appendChild(p),t.appendChild(n),t}hideAllPopups(){this.activePopups.forEach(e=>this.hidePopup(e)),this.activePopups.clear()}hidePopup(e){e&&(e.classList.add("typeaware-fade-out"),setTimeout(()=>{e.parentNode&&e.parentNode.removeChild(e),this.activePopups.delete(e)},d.UI.ANIMATION_DURATION))}capitalizeFirst(e){return e.charAt(0).toUpperCase()+e.slice(1)}}class f{constructor(){this.observer=null,this.processedElements=new WeakSet,this.debounceTimer=null,this.batchQueue=[],this.isProcessing=!1,this.eventListeners=new WeakMap,this.isDestroyed=!1}initializeObserver(e,t){this.observer=new window.MutationObserver(o=>{this.debounceProcessing(()=>this.processMutations(o,e,t))}),this.observer.observe(document.body,{childList:!0,subtree:!0,characterData:!0})}debounceProcessing(e){clearTimeout(this.debounceTimer),this.debounceTimer=setTimeout(e,d.DETECTION_THRESHOLDS.DEBOUNCE_DELAY)}processMutations(e,t,o){const s=new Set;e.forEach(i=>{if(i.type==="childList")i.addedNodes.forEach(n=>{n.nodeType===Node.ELEMENT_NODE&&this.findTextElements(n).forEach(r=>s.add(r))});else if(i.type==="characterData"){const n=i.target.parentElement;n&&this.isTextElement(n)&&s.add(n)}}),s.size>0&&(this.batchQueue.push(...Array.from(s)),this.processBatch(t,o))}findTextElements(e){const t=[],o=document.createTreeWalker(e,NodeFilter.SHOW_ELEMENT,{acceptNode:i=>this.isTextElement(i)&&i.textContent.trim().length>0?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP});let s;for(;s=o.nextNode();)t.push(s);return t}isTextElement(e){const t=e.tagName.toLowerCase();return!(["script","style","noscript","meta","link"].includes(t)||this.processedElements.has(e))}async processBatch(e,t){if(this.isProcessing||this.isDestroyed)return;this.isProcessing=!0;const o=this.batchQueue.splice(0,d.DETECTION_THRESHOLDS.BATCH_SIZE);for(const s of o){if(this.isDestroyed)break;let i=s.textContent.trim();i.length>d.DETECTION_THRESHOLDS.MAX_TEXT_LENGTH&&(i=i.substring(0,d.DETECTION_THRESHOLDS.MAX_TEXT_LENGTH));const n=await e.detectContent(i,s);n&&n.category!=="none"&&t.highlightElement(s,n)}this.isProcessing=!1,this.batchQueue.length>0&&!this.isDestroyed&&await this.processBatch(e,t)}destroy(){this.isDestroyed||(this.isDestroyed=!0,this.observer&&(this.observer.disconnect(),this.observer=null),this.debounceTimer&&(clearTimeout(this.debounceTimer),this.debounceTimer=null),this.batchQueue.length=0,console.log("ContentScanObserver cleanup completed"))}}const g=new y,l=new m,c=new f;c.initializeObserver(g,l);function u(){const a=c.findTextElements(document.body);c.batchQueue.push(...a),c.processBatch(g,l)}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",u):u();chrome.runtime.onMessage.addListener((a,e,t)=>{a.action==="toggleExtension"&&(a.enabled||l.removeAllHighlights())});window.addEventListener("beforeunload",()=>{console.log("TypeAware: Cleaning up content script resources"),c&&c.destroy(),l&&l.hideAllPopups(),document.querySelectorAll(".typeaware-highlight").forEach(e=>{e.classList.remove("typeaware-highlight")});const a=document.querySelector("style[data-typeaware]");a&&a.remove()});document.addEventListener("visibilitychange",()=>{document.hidden&&c&&c.debounceTimer&&(clearTimeout(c.debounceTimer),c.debounceTimer=null)});
