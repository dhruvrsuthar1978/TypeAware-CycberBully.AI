const u={HARASSMENT:{severity:"high",color:"#dc2626",patterns:[/\b(loser|stupid|idiot|dumb|fool|hate you|kill yourself|kys)\b/gi,/stfu|shut.*up|go away|nobody likes/gi,/you're.*trash|you suck/gi]},HATE_SPEECH:{severity:"high",color:"#b91c1c",patterns:[/\b(damn|hell|crap)\b/gi,/(slur words would go here)/gi]},PROFANITY:{severity:"medium",color:"#ea580c",patterns:[/\b(hell|damn|crap|sucks?|pissed)\b/gi]},SPAM:{severity:"low",color:"#ca8a04",patterns:[/buy now|click here|limited time|act now/gi,/follow my link|check my profile/gi]}},n={EXTENSION_ID:chrome.runtime.id,DETECTION_THRESHOLDS:{MIN_TEXT_LENGTH:3,BATCH_SIZE:5,DEBOUNCE_DELAY:300},UI:{POPUP_FADE_DELAY:5e3,ANIMATION_DURATION:200}};class h{constructor(){this.cache=new Map,this.processingQueue=new Set}async detectContent(e,t){if(!e||e.length<n.DETECTION_THRESHOLDS.MIN_TEXT_LENGTH)return null;const o=this.analyzeWithPatterns(e);return o&&o.category!=="none"&&this.logDetection(o,e,t),o}analyzeWithPatterns(e){for(const[t,o]of Object.entries(u))for(const r of o.patterns)if(r.test(e))return{category:t.toLowerCase(),severity:o.severity,confidence:.85,explanation:`Detected ${t.replace(/_/g," ").toLowerCase()} in content`,suggestion:"Consider using more respectful language",color:o.color};return{category:"none",severity:"low",confidence:0,explanation:"",suggestion:"",color:""}}async logDetection(e,t,o){var r;try{const s={platform:this.detectPlatform(),url:window.location.href,timestamp:Date.now(),category:e.category,severity:e.severity,confidence:e.confidence,textLength:t.length,elementType:((r=o==null?void 0:o.tagName)==null?void 0:r.toLowerCase())||"unknown"};await chrome.runtime.sendMessage({action:"updateStats",data:{totalScanned:1,threatsDetected:1}}),console.log("Threat detected:",s)}catch(s){console.error("Detection logging error:",s)}}detectPlatform(){const e=window.location.hostname.toLowerCase();return e.includes("instagram.com")?"instagram":e.includes("twitter.com")||e.includes("x.com")?"twitter":e.includes("youtube.com")?"youtube":e.includes("reddit.com")?"reddit":e.includes("facebook.com")?"facebook":"web"}}class g{constructor(){this.activePopups=new Set,this.stylesInjected=!1,this.injectStyles()}injectStyles(){if(this.stylesInjected)return;const e=document.createElement("style");e.textContent=`
      .typeaware-highlight {
        position: relative;
        background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(220, 38, 38, 0.15));
        border-radius: 4px;
        border: 2px solid rgba(239, 68, 68, 0.5);
        padding: 2px 4px;
        margin: 0 1px;
        cursor: pointer;
        transition: all 0.2s ease;
        box-shadow: 0 0 8px rgba(239, 68, 68, 0.3);
      }

      .typeaware-highlight:hover {
        background: linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(220, 38, 38, 0.25));
        border-color: rgba(239, 68, 68, 0.7);
        box-shadow: 0 0 12px rgba(239, 68, 68, 0.5);
      }

      .typeaware-popup {
        position: fixed;
        background: white;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        border: 2px solid #dc2626;
        z-index: 999999;
        max-width: 350px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 14px;
        opacity: 0;
        transform: translateY(-10px) scale(0.95);
        transition: all 0.2s ease;
        pointer-events: none;
      }

      .typeaware-popup.visible {
        opacity: 1;
        transform: translateY(0) scale(1);
        pointer-events: auto;
      }

      .typeaware-popup-header {
        padding: 12px 16px;
        border-bottom: 2px solid #dc2626;
        background: linear-gradient(135deg, #fef2f2, #fee2e2);
        border-radius: 10px 10px 0 0;
        font-weight: 600;
        color: #dc2626;
      }

      .typeaware-popup-content {
        padding: 12px 16px;
        font-size: 13px;
        color: #374151;
      }

      .typeaware-popup-suggestion {
        background: #f0fdf4;
        border: 1px solid #86efac;
        border-radius: 6px;
        padding: 8px 12px;
        margin-top: 8px;
        font-style: italic;
        color: #166534;
        cursor: pointer;
        transition: all 0.15s ease;
      }

      .typeaware-popup-suggestion:hover {
        background: #dcfce7;
        border-color: #4ade80;
      }

      .typeaware-popup-actions {
        padding: 8px 16px 12px;
        border-top: 1px solid #e5e7eb;
        display: flex;
        gap: 8px;
        justify-content: flex-end;
      }

      .typeaware-btn {
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        border: none;
        transition: all 0.15s ease;
      }

      .typeaware-btn-primary {
        background: #dc2626;
        color: white;
      }

      .typeaware-btn-primary:hover {
        background: #b91c1c;
      }

      .typeaware-btn-secondary {
        background: #f1f5f9;
        color: #475569;
        border: 1px solid #e2e8f0;
      }

      .typeaware-btn-secondary:hover {
        background: #e2e8f0;
      }

      .typeaware-fade-out {
        opacity: 0 !important;
        transform: translateY(-10px) scale(0.95) !important;
      }
    `,document.head.appendChild(e),this.stylesInjected=!0}highlightElement(e,t){e.classList.contains("typeaware-highlight")||(e.classList.add("typeaware-highlight"),e.setAttribute("data-typeaware-category",t.category),e.setAttribute("data-typeaware-severity",t.severity),e.addEventListener("click",o=>{o.stopPropagation(),this.showSuggestionPopup(e,t)}))}showSuggestionPopup(e,t){this.hideAllPopups();const o=e.getBoundingClientRect(),r=this.createPopup(t);r.style.left=`${o.left+window.scrollX}px`,r.style.top=`${o.bottom+window.scrollY+5}px`,document.body.appendChild(r),setTimeout(()=>r.classList.add("visible"),10),setTimeout(()=>this.hidePopup(r),n.UI.POPUP_FADE_DELAY),this.activePopups.add(r)}createPopup(e){const t=document.createElement("div");return t.className="typeaware-popup",t.innerHTML=`
      <div class="typeaware-popup-header">
        ⚠️ ${this.capitalizeFirst(e.category)} Detected
      </div>
      <div class="typeaware-popup-content">
        <p style="margin: 0 0 8px; color: #6b7280;">
          ${e.explanation||"This content may be harmful or inappropriate."}
        </p>
        ${e.suggestion?`
          <div class="typeaware-popup-suggestion">
            💡 ${e.suggestion}
          </div>
        `:""}
      </div>
      <div class="typeaware-popup-actions">
        <button class="typeaware-btn typeaware-btn-secondary" onclick="this.closest('.typeaware-popup').remove()">
          Dismiss
        </button>
        <button class="typeaware-btn typeaware-btn-primary" onclick="window.open('https://typeaware.com', '_blank')">
          Learn More
        </button>
      </div>
    `,t}hideAllPopups(){this.activePopups.forEach(e=>this.hidePopup(e)),this.activePopups.clear()}hidePopup(e){e&&(e.classList.add("typeaware-fade-out"),setTimeout(()=>{e.parentNode&&e.parentNode.removeChild(e),this.activePopups.delete(e)},n.UI.ANIMATION_DURATION))}capitalizeFirst(e){return e.charAt(0).toUpperCase()+e.slice(1)}}class y{constructor(){this.observer=null,this.processedElements=new WeakSet,this.debounceTimer=null,this.batchQueue=[],this.isProcessing=!1}initializeObserver(e,t){this.observer=new window.MutationObserver(o=>{this.debounceProcessing(()=>this.processMutations(o,e,t))}),this.observer.observe(document.body,{childList:!0,subtree:!0,characterData:!0})}debounceProcessing(e){clearTimeout(this.debounceTimer),this.debounceTimer=setTimeout(e,n.DETECTION_THRESHOLDS.DEBOUNCE_DELAY)}processMutations(e,t,o){const r=new Set;e.forEach(s=>{if(s.type==="childList")s.addedNodes.forEach(a=>{a.nodeType===Node.ELEMENT_NODE&&this.findTextElements(a).forEach(l=>r.add(l))});else if(s.type==="characterData"){const a=s.target.parentElement;a&&this.isTextElement(a)&&r.add(a)}}),r.size>0&&(this.batchQueue.push(...Array.from(r)),this.processBatch(t,o))}findTextElements(e){const t=[],o=document.createTreeWalker(e,NodeFilter.SHOW_ELEMENT,{acceptNode:s=>this.isTextElement(s)&&s.textContent.trim().length>0?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP});let r;for(;r=o.nextNode();)t.push(r);return t}isTextElement(e){const t=e.tagName.toLowerCase();return!(["script","style","noscript","meta","link"].includes(t)||this.processedElements.has(e))}async processBatch(e,t){if(this.isProcessing)return;this.isProcessing=!0;const o=this.batchQueue.splice(0,n.DETECTION_THRESHOLDS.BATCH_SIZE);for(const r of o){const s=r.textContent.trim(),a=await e.detectContent(s,r);a&&a.category!=="none"&&t.highlightElement(r,a)}this.isProcessing=!1,this.batchQueue.length>0&&await this.processBatch(e,t)}}const p=new h,d=new g,c=new y;c.initializeObserver(p,d);document.addEventListener("DOMContentLoaded",()=>{const i=c.findTextElements(document.body);c.batchQueue.push(...i),c.processBatch(p,d)});chrome.runtime.onMessage.addListener((i,e,t)=>{i.action==="toggleExtension"&&(i.enabled||document.querySelectorAll(".typeaware-highlight").forEach(o=>{o.classList.remove("typeaware-highlight")}))});
