class l{constructor(){this.isEnabled=!0,this.processed=new Set,this.abusivePatterns=this.initializePatterns(),this.suggestions=this.initializeSuggestions(),this.init()}async init(){const t=await chrome.storage.local.get(["enabled"]);this.isEnabled=t.enabled!==!1,this.isEnabled&&this.startDetection(),chrome.runtime.onMessage.addListener((e,s,n)=>{e.action==="toggleExtension"&&(this.isEnabled=e.enabled,this.isEnabled?this.startDetection():this.stopDetection())})}initializePatterns(){return{harassment:[/\b(kill\s+yourself|kys)\b/gi,/\b(you\s+suck|you're\s+stupid|idiot|moron)\b/gi,/\b(shut\s+up|stfu)\b/gi,/\b(loser|pathetic|worthless)\b/gi],hate:[/\b(racist|fascist|nazi)\b/gi,/\b(hate\s+you|i\s+hate)\b/gi,/\b(disgusting|gross|sick)\b/gi],spam:[/\b(buy\s+now|click\s+here|free\s+money)\b/gi,/\b(amazing\s+offer|limited\s+time)\b/gi,/\b(www\.|http|\.com)\b/gi],profanity:[/\b(f[u\*]ck|sh[i\*]t|damn|hell)\b/gi,/\b(b[i\*]tch|a[s\*]{2}hole)\b/gi],threats:[/\b(i'll\s+kill|gonna\s+hurt|beat\s+you\s+up)\b/gi,/\b(watch\s+out|you're\s+dead)\b/gi,/\b(threat|violence|harm)\b/gi]}}initializeSuggestions(){return{harassment:["I disagree with your point of view","That's not how I see it","I think differently about this"],hate:["I respectfully disagree","We have different perspectives","I see this differently"],spam:["Here's something you might find interesting","I'd like to share this with you","You might want to check this out"],profanity:["That's really frustrating","This is quite annoying","I'm disappointed by this"],threats:["I'm really upset about this","This situation is very frustrating","I strongly disagree with this"]}}startDetection(){console.log("TypeAware detection started"),this.scanPage(),this.observer=new MutationObserver(t=>{t.forEach(e=>{e.addedNodes.forEach(s=>{s.nodeType===Node.ELEMENT_NODE&&this.scanElement(s)})})}),this.observer.observe(document.body,{childList:!0,subtree:!0}),this.monitorInputs()}stopDetection(){console.log("TypeAware detection stopped"),this.observer&&this.observer.disconnect(),document.querySelectorAll(".typeaware-warning").forEach(t=>t.remove()),document.querySelectorAll(".typeaware-overlay").forEach(t=>t.remove())}scanPage(){this.getPlatformSelectors().forEach(e=>{document.querySelectorAll(e).forEach(s=>{this.scanElement(s)})})}getPlatformSelectors(){const t=window.location.hostname;return t.includes("twitter.com")||t.includes("x.com")?['[data-testid="tweetText"]','[data-testid="tweet"]','div[role="textbox"]']:t.includes("youtube.com")?["#content-text","#comment-content",".comment-text"]:t.includes("reddit.com")?[".usertext-body",".md",'[data-testid="comment"]']:t.includes("facebook.com")?['[data-testid="post_message"]',".userContent",'div[role="textbox"]']:["p","div","span","textarea",'input[type="text"]']}scanElement(t){if(this.processed.has(t)||!t.textContent)return;this.processed.add(t);const e=t.textContent.trim();if(e.length<3)return;const s=this.detectAbusiveContent(e);s.isAbusive&&this.handleAbusiveContent(t,s,e),this.updateStats({totalScanned:1})}detectAbusiveContent(t){const e={isAbusive:!1,types:[],confidence:0,matches:[]};for(const[s,n]of Object.entries(this.abusivePatterns))for(const o of n){const i=t.match(o);i&&(e.isAbusive=!0,e.types.push(s),e.matches.push(...i),e.confidence=Math.max(e.confidence,.8))}return e.isAbusive||((t.match(/[A-Z]/g)||[]).length/t.length>.7&&t.length>10&&(e.isAbusive=!0,e.types.push("aggressive"),e.confidence=.6),/(.)\1{4,}/.test(t)&&(e.isAbusive=!0,e.types.push("spam"),e.confidence=.5)),e}handleAbusiveContent(t,e,s){this.createWarningOverlay(t,e,s),t.style.filter="blur(3px)",t.style.opacity="0.7",this.storeDetection(e,s),this.updateStats({threatsDetected:1})}createWarningOverlay(t,e,s){const n=document.createElement("div");n.className="typeaware-overlay",n.style.cssText=`
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(255, 0, 0, 0.1);
      border: 2px solid #ef4444;
      border-radius: 8px;
      z-index: 10000;
      pointer-events: none;
    `;const o=t.offsetParent||t.parentElement;o&&getComputedStyle(o).position==="static"&&(o.style.position="relative");const i=document.createElement("div");i.className="typeaware-warning",i.style.cssText=`
      position: absolute;
      top: -40px;
      left: 0;
      background: #ef4444;
      color: white;
      padding: 8px 12px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 600;
      white-space: nowrap;
      z-index: 10001;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    `;const c=e.types[0]||"inappropriate";i.textContent=`⚠️ Potentially ${c} content detected`;const a=document.createElement("div");a.style.cssText=`
      position: absolute;
      top: -80px;
      left: 0;
      display: flex;
      gap: 8px;
      z-index: 10002;
    `;const d=document.createElement("button");d.textContent="Show",d.style.cssText=`
      background: #3b82f6;
      color: white;
      border: none;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      cursor: pointer;
    `,d.onclick=()=>{t.style.filter="none",t.style.opacity="1",n.remove()};const r=document.createElement("button");r.textContent="Report",r.style.cssText=`
      background: #ef4444;
      color: white;
      border: none;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      cursor: pointer;
    `,r.onclick=()=>{this.reportContent(e,s),r.textContent="Reported",r.style.background="#10b981"};const p=document.createElement("button");return p.textContent="Suggest",p.style.cssText=`
      background: #10b981;
      color: white;
      border: none;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      cursor: pointer;
    `,p.onclick=()=>{this.showSuggestions(t,e,s)},a.appendChild(d),a.appendChild(r),a.appendChild(p),n.appendChild(i),n.appendChild(a),t.style.position="relative",t.appendChild(n),n}showSuggestions(t,e,s){const n=e.types[0]||"harassment",o=this.suggestions[n]||this.suggestions.harassment,i=document.createElement("div");i.style.cssText=`
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: white;
      border: 2px solid #e5e7eb;
      border-radius: 12px;
      padding: 20px;
      max-width: 400px;
      z-index: 20000;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
    `,i.innerHTML=`
      <h3 style="margin: 0 0 12px 0; color: #374151; font-size: 16px;">Suggested Alternatives</h3>
      <p style="margin: 0 0 16px 0; color: #6b7280; font-size: 14px;">Consider using one of these alternatives:</p>
      <div style="margin-bottom: 16px;">
        ${o.map(c=>`
          <div style="
            background: #f3f4f6;
            padding: 8px 12px;
            margin: 4px 0;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            border: 1px solid transparent;
          " 
          class="suggestion-item"
          onmouseover="this.style.background='#e5e7eb'; this.style.borderColor='#d1d5db'"
          onmouseout="this.style.background='#f3f4f6'; this.style.borderColor='transparent'"
          onclick="navigator.clipboard.writeText('${c}'); this.innerHTML='✓ Copied to clipboard';"
          >${c}</div>
        `).join("")}
      </div>
      <button onclick="this.parentElement.remove()" style="
        background: #6b7280;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 6px;
        cursor: pointer;
        float: right;
      ">Close</button>
    `,document.body.appendChild(i),setTimeout(()=>{i.parentElement&&i.remove()},1e4)}monitorInputs(){document.addEventListener("input",t=>{if(!this.isEnabled)return;const e=t.target;if(e.tagName==="TEXTAREA"||e.tagName==="INPUT"&&e.type==="text"||e.contentEditable==="true"){const s=e.value||e.textContent;if(s&&s.length>10){const n=this.detectAbusiveContent(s);n.isAbusive?this.showInputWarning(e,n):this.hideInputWarning(e)}}})}showInputWarning(t,e){this.hideInputWarning(t);const s=document.createElement("div");s.className="typeaware-input-warning",s.style.cssText=`
      position: absolute;
      bottom: 100%;
      left: 0;
      background: #fef2f2;
      border: 1px solid #fecaca;
      color: #dc2626;
      padding: 8px 12px;
      border-radius: 6px;
      font-size: 12px;
      margin-bottom: 4px;
      z-index: 10000;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    `;const n=e.types[0]||"inappropriate";s.innerHTML=`
      <div style="font-weight: 600; margin-bottom: 4px;">⚠️ Potentially ${n} content</div>
      <div style="font-size: 11px;">Consider rephrasing your message</div>
    `,t.style.position="relative",t.parentElement.style.position="relative",t.parentElement.appendChild(s)}hideInputWarning(t){var s;const e=(s=t.parentElement)==null?void 0:s.querySelector(".typeaware-input-warning");e&&e.remove()}async storeDetection(t,e){const n=(await chrome.storage.local.get(["detections"])).detections||[];n.push({...t,content:e.substring(0,200),platform:window.location.hostname,url:window.location.href,timestamp:new Date().toISOString()}),n.length>50&&n.splice(0,n.length-50),await chrome.storage.local.set({detections:n})}reportContent(t,e){chrome.runtime.sendMessage({action:"reportContent",data:{content:e.substring(0,500),types:t.types,confidence:t.confidence,platform:window.location.hostname,url:window.location.href,userAgent:navigator.userAgent}})}updateStats(t){chrome.runtime.sendMessage({action:"updateStats",data:t})}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{new l}):new l;
