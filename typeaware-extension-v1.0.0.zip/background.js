// Initialize extension on install
chrome.runtime.onInstalled.addListener(async () => {
  // Initialize default storage
  const data = await chrome.storage.local.get(['stats', 'enabled']);

  if (!data.stats) {
    await chrome.storage.local.set({
      stats: {
        totalScanned: 0,
        threatsDetected: 0,
        reportsSubmitted: 0
      }
    });
  }

  if (data.enabled === undefined) {
    await chrome.storage.local.set({ enabled: true });
  }

  // Initialize detections array if needed
  const detData = await chrome.storage.local.get(['detections']);
  if (!detData.detections) {
    await chrome.storage.local.set({ detections: [] });
  }
});

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'updateStats') {
    updateStats(request.data).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (request.action === 'addDetection') {
    addDetection(request.detection).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (request.action === 'getStats') {
    chrome.storage.local.get(['stats'], (result) => {
      sendResponse({ stats: result.stats });
    });
    return true;
  }
});

// Update stats
async function updateStats(updates) {
  const result = await chrome.storage.local.get(['stats']);
  const stats = result.stats || { totalScanned: 0, threatsDetected: 0, reportsSubmitted: 0 };

  stats.totalScanned += updates.totalScanned || 0;
  stats.threatsDetected += updates.threatsDetected || 0;
  stats.reportsSubmitted += updates.reportsSubmitted || 0;

  await chrome.storage.local.set({ stats });
}

// Add detection to history
async function addDetection(detection) {
  const result = await chrome.storage.local.get(['detections']);
  let detections = result.detections || [];

  detections.unshift(detection);

  // Keep only last 100 detections
  if (detections.length > 100) {
    detections = detections.slice(0, 100);
  }

  await chrome.storage.local.set({ detections });
}